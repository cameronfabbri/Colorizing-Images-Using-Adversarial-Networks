LOSS_METHOD:      gan
DATA_DIR:         /mnt/data2/images/celeba/images/
GAN_EPOCHS:       8
PRETRAIN_EPOCHS:  0
NUM_CRITIC:       5
BATCH_SIZE:       4
DATASET:          celeba
GAN_LR:           0.0001
ARCHITECTURE:     pix2pix
NUM_GPU:          1
PRETRAIN_LR:      None
L1_WEIGHT:        0.0
L2_WEIGHT:        1.0
GAN_WEIGHT:       1.0


